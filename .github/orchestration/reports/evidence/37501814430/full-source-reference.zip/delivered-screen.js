const {Existing}=require('../../shared/ui/Existing');let selected=false;module.exports={Existing,toggle(){return selected=!selected;}};
