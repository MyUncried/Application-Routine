const {Existing}=require('../../shared/ui/Existing');
let selection = false;
function toggle() {
  selection = !selection;
  return selection;
}
module.exports = {Existing, toggle};
