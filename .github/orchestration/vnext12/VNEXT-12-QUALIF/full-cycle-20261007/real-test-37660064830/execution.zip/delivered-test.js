'use strict';

// Disposable functional protocol test. Node built-ins only, no framework globals.
// Run from the repository root: node tests/ui.test.js
// Exit status 0 means every assertion held; any failure exits non-zero.

const path = require('node:path');
const {spawnSync} = require('node:child_process');

// Absolute filenames resolved from this test's own location, never from process.cwd().
const screenPath = require.resolve(path.join(__dirname, '../src/features/example/Screen.js'));
const keepPath = require.resolve(path.join(__dirname, '../src/shared/ui/Existing.js'));

// Isolated toggle probe: one fresh Node process, one Screen module instance, four ordered calls.
const toggleProbeSource = `
'use strict';
const assert = require('node:assert');
const screen = require(require.resolve(process.argv[1]));
assert.strictEqual(typeof screen.toggle, 'function', 'Screen.toggle must be a function');
const observed = [screen.toggle(), screen.toggle(), screen.toggle(), screen.toggle()];
assert.deepStrictEqual(
  observed,
  [true, false, true, false],
  'toggle() must start off and alternate; observed ' + JSON.stringify(observed)
);
process.stdout.write('toggle-sequence=' + JSON.stringify(observed) + '\\n');
`;

// Shared-export probe: baseline value, normal re-export identity, then sentinel reference identity.
const sharedExportProbeSource = `
'use strict';
const assert = require('node:assert');
const screenFile = require.resolve(process.argv[1]);
const keepFile = require.resolve(process.argv[2]);

const priorScreenEntry = require.cache[screenFile];
const priorKeepEntry = require.cache[keepFile];

delete require.cache[screenFile];
delete require.cache[keepFile];

const shared = require(keepFile);
const originalExisting = shared.Existing;
assert.strictEqual(originalExisting, true, 'baseline shared Existing must be true');

const screen = require(screenFile);
assert.strictEqual(screen.Existing, shared.Existing, 'Screen must re-export the shared Existing value');
assert.strictEqual(screen.Existing, true, 'normal Existing export identity must be the baseline true');

const sentinel = {kodjoSentinel: 'shared-export-' + process.pid};
try {
  delete require.cache[screenFile];
  shared.Existing = sentinel;
  const rewired = require(screenFile);
  assert.strictEqual(rewired.Existing, sentinel, 'Screen must take Existing from the shared module by reference');
} finally {
  shared.Existing = originalExisting;
  if (priorKeepEntry === undefined) {
    delete require.cache[keepFile];
  } else {
    require.cache[keepFile] = priorKeepEntry;
  }
  if (priorScreenEntry === undefined) {
    delete require.cache[screenFile];
  } else {
    require.cache[screenFile] = priorScreenEntry;
  }
}

assert.notStrictEqual(shared.Existing, sentinel, 'no sentinel may remain in the shared export');
assert.strictEqual(shared.Existing, originalExisting, 'shared Existing must be restored to its exact original value');
assert.strictEqual(shared.Existing, true, 'restored shared Existing must be the baseline true');
process.stdout.write('shared-export=preserved\\n');
`;

function runProbe(name, source) {
  const child = spawnSync(process.execPath, ['-e', source, screenPath, keepPath], {encoding: 'utf8'});
  const failures = [];
  if (child.error) {
    failures.push('spawn error: ' + child.error.message);
  }
  if (child.signal !== null) {
    failures.push('terminated by signal ' + child.signal);
  }
  if (child.status !== 0) {
    failures.push('exit status ' + child.status + ' (expected 0)');
  }
  if (failures.length > 0) {
    process.stderr.write('FAIL ' + name + ': ' + failures.join('; ') + '\n');
    process.stderr.write('--- ' + name + ' stdout ---\n' + (child.stdout || '') + '\n');
    process.stderr.write('--- ' + name + ' stderr ---\n' + (child.stderr || '') + '\n');
    process.exit(1);
  }
  process.stdout.write('ok ' + name + ': ' + (child.stdout || '').trim() + '\n');
}

runProbe('isolated-toggle', toggleProbeSource);
runProbe('shared-export-preservation', sharedExportProbeSource);
process.stdout.write('ok tests/ui.test.js\n');
