'use strict';
const { spawnSync } = require('node:child_process');
const path = require('node:path');
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx';
const commands = {
  jest: [npm, ['test', '--silent']],
  typescript: [npx, ['--no-install', 'tsc', '--noEmit']],
  lint: [npm, ['run', 'lint', '--silent']]
};
const id = process.argv[2];
if (!Object.prototype.hasOwnProperty.call(commands, id)) process.exit(78);
const env = { ...process.env };
if (env.KODJO_QUALIFICATION_ISOLATED_CHECKS === '1') {
  if (id === 'jest') {
    const cacheRoot = String(env.KODJO_QUALIFICATION_CHECK_CACHE_DIR || '').trim();
    if (cacheRoot) commands[id][1].push('--', '--cacheDirectory', path.join(cacheRoot, 'jest'));
    else commands[id][1].push('--', '--no-cache');
  }
  if (id === 'lint') commands[id][1].push('--', '--no-cache');
}
delete env.CLAUDE_CODE_OAUTH_TOKEN;
delete env.ANTHROPIC_API_KEY;
const child = process.platform === 'win32'
  ? { bin: (process.env.ComSpec || 'cmd.exe'), args: ['/d', '/s', '/c', commands[id][0], ...commands[id][1]] }
  : { bin: commands[id][0], args: commands[id][1] };
const result = spawnSync(child.bin, child.args, { cwd: process.cwd(), env, shell: false, stdio: 'inherit', windowsHide: true });
process.exit(result.error || result.status === null ? 78 : result.status);
